# Mossy Jungle Add-on (Bedrock 1.26.63.1)

## What this prototype does
- Adds a separate custom dimension: `mossy_jungle:dimension`.
- A player uses an ordinary vanilla lever beside the vanilla Ancient City reinforced-deepslate frame.
- The script checks for nearby reinforced deepslate before teleporting.
- The destination is built as a 300 x 300 mossy island with warped-stem trunks, warped-wart-block foliage, moss, and occasional wool tents with hay-bale sleeping areas.
- A return lever is provided at the destination.

## Important limitations
- Bedrock custom dimensions currently support the `void` generator only. This add-on therefore builds a finite island with script commands; it is not infinite natural terrain.
- The tent system rolls a 25% chance at each 100-block grid point on the generated island. It does not generate structures infinitely as the player explores.
- Vanilla warped stem and warped wart blocks are used as close visual stand-ins for your purple wood and teal leaves. The block-designer links specify colors, not downloadable texture files, so exact custom textures are not included yet.
- The script detects a nearby reinforced-deepslate frame by counting nearby blocks. It does not identify the full Ancient City structure or verify exact frame geometry. If your lever is close to other reinforced deepslate, it may also pass the check.
- This is a first playable prototype. It has not been run inside your dedicated server, so test it in a copy of your world first.

## Install
1. Unzip the download.
2. Copy `Mossy_Jungle_BP` into your Bedrock Dedicated Server `behavior_packs` folder.
3. Add this pack to the test world's `world_behavior_packs.json` using the pack header UUID from `manifest.json`:
   ```json
   [
     {
       "pack_id": "0b8bf345-d619-4ee7-93e6-b75fc580c299",
       "version": [1, 0, 0]
     }
   ]
   ```
4. Start the server and check the content log for script or dimension errors.
5. In an Ancient City, place a normal lever beside the reinforced-deepslate frame and flip it.
6. In the destination, use the return lever on the spawn platform.

Back up your world before testing. Do not test this first on your only world.
