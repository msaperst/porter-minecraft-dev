MOSSY JUNGLE - LEVER FIX

This version fixes the invalid playerInteractWithBlock subscription and uses:
world.afterEvents.leverAction

INSTALL CAREFULLY:
1. Back up your world.
2. Remove/disable the older Mossy Jungle behavior pack version.
3. Import this updated .mcaddon.
4. Activate the updated behavior pack in the test world.
5. Fully stop and restart the dedicated server.
6. Check the server content log for:
   [Mossy Jungle] Script loaded. leverAction listener registered.
7. Place a normal lever within 5 blocks of the Ancient City reinforced-deepslate frame and switch it ON.

Expected chat:
- "Mossy Jungle: lever detected! Checking the Ancient City frame..."
- Then either an explanation that the frame wasn't detected, or a message that it was detected.

If there is no startup log line, the script is still not loading. Send the server content log.

This is a prototype. The dimension is a finite script-built island and has not been tested on your server.
