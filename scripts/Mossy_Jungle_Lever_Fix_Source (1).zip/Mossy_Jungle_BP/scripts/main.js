import { world, system } from "@minecraft/server";

const DIMENSION_ID = "mossy_jungle:dimension";
const SPAWN = { x: 0, y: 82, z: 0 };
const RETURN_LEVER = { x: 0, y: 82, z: 8 };
const PORTAL_CHECK_RADIUS = 5;
const MIN_REINFORCED_DEEPSLATE = 6;

let dimensionBuilt = false;
const returnLocations = new Map();

/*
 * This pack uses the vanilla Ancient City reinforced-deepslate frame.
 * A player places an ordinary lever beside that frame and flips it.
 * We verify that reinforced deepslate is nearby before teleporting.
 */

function countNearbyReinforcedDeepslate(dimension, location) {
    let count = 0;

    for (let x = -PORTAL_CHECK_RADIUS; x <= PORTAL_CHECK_RADIUS; x++) {
        for (let y = -3; y <= 5; y++) {
            for (let z = -PORTAL_CHECK_RADIUS; z <= PORTAL_CHECK_RADIUS; z++) {
                const block = dimension.getBlock({
                    x: Math.floor(location.x) + x,
                    y: Math.floor(location.y) + y,
                    z: Math.floor(location.z) + z
                });

                if (block?.typeId === "minecraft:reinforced_deepslate") {
                    count++;
                }
            }
        }
    }

    return count;
}

function runFill(dimension, from, to, block) {
    dimension.runCommand(
        `fill ${from.x} ${from.y} ${from.z} ${to.x} ${to.y} ${to.z} ${block}`
    );
}

function placeBlock(dimension, x, y, z, block) {
    const target = dimension.getBlock({ x, y, z });
    if (target) target.setType(block);
}

function buildTent(dimension, x, z) {
    // 7 x 7 wool tent, with a hay-bale sleeping area.
    runFill(dimension, { x: x - 3, y: 80, z: z - 3 }, { x: x + 3, y: 80, z: z + 3 }, "minecraft:gray_wool");
    runFill(dimension, { x: x - 3, y: 81, z: z - 3 }, { x: x + 3, y: 83, z: z - 3 }, "minecraft:light_gray_wool");
    runFill(dimension, { x: x - 3, y: 81, z: z + 3 }, { x: x + 3, y: 83, z: z + 3 }, "minecraft:light_gray_wool");
    runFill(dimension, { x: x - 3, y: 81, z: z - 2 }, { x: x - 3, y: 83, z: z + 2 }, "minecraft:light_gray_wool");
    runFill(dimension, { x: x + 3, y: 81, z: z - 2 }, { x: x + 3, y: 83, z: z + 2 }, "minecraft:light_gray_wool");

    // Sloped-looking roof made from wool layers.
    runFill(dimension, { x: x - 2, y: 84, z: z - 2 }, { x: x + 2, y: 84, z: z + 2 }, "minecraft:white_wool");
    runFill(dimension, { x: x - 1, y: 85, z: z - 1 }, { x: x + 1, y: 85, z: z + 1 }, "minecraft:white_wool");
    placeBlock(dimension, x, 86, z, "minecraft:white_wool");

    // Entrance gap and hay bed.
    placeBlock(dimension, x, 81, z - 3, "minecraft:air");
    placeBlock(dimension, x, 82, z - 3, "minecraft:air");
    runFill(dimension, { x: x - 1, y: 81, z: z + 1 }, { x: x + 1, y: 81, z: z + 1 }, "minecraft:hay_block");
    placeBlock(dimension, x, 82, z + 1, "minecraft:red_wool");
    placeBlock(dimension, x - 2, 81, z - 1, "minecraft:campfire");
    placeBlock(dimension, x + 2, 81, z - 1, "minecraft:barrel");
}

function buildTree(dimension, x, z, height = 7) {
    // Vanilla warped blocks approximate the requested purple wood and teal foliage.
    runFill(dimension, { x, y: 81, z }, { x, y: 80 + height, z }, "minecraft:warped_stem");
    for (let dy = height - 2; dy <= height + 1; dy++) {
        const radius = dy === height + 1 ? 1 : 2;
        runFill(
            dimension,
            { x: x - radius, y: 80 + dy, z: z - radius },
            { x: x + radius, y: 80 + dy, z: z + radius },
            "minecraft:warped_wart_block"
        );
    }
    placeBlock(dimension, x, 80 + height + 2, z, "minecraft:warped_wart_block");
}

function buildMossyJungle() {
    const dimension = world.getDimension(DIMENSION_ID);

    // Build a 300 x 300 island in 32-block sections to avoid oversized fill commands.
    for (let x = -150; x < 150; x += 30) {
        for (let z = -150; z < 150; z += 30) {
            const maxX = Math.min(x + 29, 149);
            const maxZ = Math.min(z + 29, 149);
            runFill(dimension, { x, y: 76, z }, { x: maxX, y: 78, z: maxZ }, "minecraft:stone");
            runFill(dimension, { x, y: 79, z }, { x: maxX, y: 79, z: maxZ }, "minecraft:dirt");
            runFill(dimension, { x, y: 80, z }, { x: maxX, y: 80, z: maxZ }, "minecraft:moss_block");
            runFill(dimension, { x, y: 81, z }, { x: maxX, y: 81, z: maxZ }, "minecraft:moss_block");
        }
    }

    // Mossy clearings and scattered jungle plants.
    for (let i = 0; i < 42; i++) {
        const x = Math.floor(Math.random() * 270) - 135;
        const z = Math.floor(Math.random() * 270) - 135;
        if (Math.abs(x) < 15 && Math.abs(z) < 15) continue;
        buildTree(dimension, x, z, 5 + Math.floor(Math.random() * 5));
    }

    // One 25% roll at each 100-block grid location.
    // This produces a scattered set of abandoned wool tents across the island.
    for (let x = -100; x <= 100; x += 100) {
        for (let z = -100; z <= 100; z += 100) {
            if (Math.random() < 0.25) {
                buildTent(dimension, x + 12, z + 12);
            }
        }
    }

    // A visible return lever on a small stone pad.
    runFill(dimension, { x: -3, y: 81, z: 5 }, { x: 3, y: 81, z: 11 }, "minecraft:polished_deepslate");
    placeBlock(dimension, RETURN_LEVER.x, RETURN_LEVER.y, RETURN_LEVER.z, "minecraft:lever");
    dimensionBuilt = true;
}

function teleportToMossyJungle(player, leverLocation) {
    const overworld = world.getDimension("minecraft:overworld");
    returnLocations.set(player.id, {
        x: Math.floor(leverLocation.x),
        y: Math.floor(leverLocation.y) + 1,
        z: Math.floor(leverLocation.z),
        dimension: overworld
    });

    if (!dimensionBuilt) {
        try {
            buildMossyJungle();
        } catch (error) {
            player.sendMessage("§cMossy Jungle could not finish generating. Check the content log.");
            console.warn(`Mossy Jungle generation error: ${error}`);
            return;
        }
    }

    player.teleport(SPAWN, { dimension: world.getDimension(DIMENSION_ID) });
    player.sendMessage("§aWelcome to the Mossy Jungle!");
}

function returnToOverworld(player) {
    const saved = returnLocations.get(player.id);
    const spawn = saved ?? world.getDefaultSpawnLocation();
    player.teleport(
        { x: spawn.x, y: spawn.y + 1, z: spawn.z },
        { dimension: world.getDimension("minecraft:overworld") }
    );
    player.sendMessage("§aYou returned to the Overworld.");
}

world.afterEvents.leverAction.subscribe((event) => {
    if (!event.isPowered) return;

    const block = event.block;
    const player = event.player;
    if (!player) return;

    if (player.dimension.id === DIMENSION_ID) {
        const dx = block.location.x - RETURN_LEVER.x;
        const dz = block.location.z - RETURN_LEVER.z;
        if (Math.abs(dx) <= 1 && Math.abs(dz) <= 1) {
            system.runTimeout(() => returnToOverworld(player), 2);
        }
        return;
    }

    if (player.dimension.id !== "minecraft:overworld") return;

    player.sendMessage("§7Mossy Jungle: lever detected! Checking the Ancient City frame...");
    const nearbyCount = countNearbyReinforcedDeepslate(player.dimension, block.location);

    if (nearbyCount < MIN_REINFORCED_DEEPSLATE) {
        player.sendMessage("§cFrame not detected. Put the lever within 5 blocks of at least 6 reinforced deepslate blocks.");
        return;
    }

    player.sendMessage("§aFrame detected! Building Mossy Jungle...");
    system.runTimeout(() => teleportToMossyJungle(player, block.location), 2);
});

world.afterEvents.playerLeave.subscribe((event) => {
    returnLocations.delete(event.playerId);
});

console.warn("[Mossy Jungle] Script loaded. leverAction listener registered.");
