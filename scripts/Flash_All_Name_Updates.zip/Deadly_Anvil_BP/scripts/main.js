import { world, EquipmentSlot } from "@minecraft/server";
import { ActionFormData } from "@minecraft/server-ui";

async function openDeadlyAnvil(player) {
    const form = new ActionFormData()
        .title("§5⚡ Flash Anvil ⚡")
        .body(
            "§dCombine your sword and Flash book!\n\n" +
            "§fMAIN HAND: §7Hold your sword\n" +
            "§fINVENTORY: §7Have a Flash book anywhere\n\n" +
            "§eSelect Apply Flash when ready."
        )
        .button("§dApply Flash")
        .button("Close");

    const response = await form.show(player);
    if (response.canceled || response.selection !== 0) return;

    const equipment = player.getComponent("minecraft:equippable");
    const inventory = player.getComponent("minecraft:inventory").container;
    const weapon = equipment.getEquipment(EquipmentSlot.Mainhand);

    if (!weapon || !weapon.typeId.endsWith("_sword")) {
        player.sendMessage("§cHold a sword first!");
        return;
    }

    if (weapon.getDynamicProperty("porter:flash") === true) {
        player.sendMessage("§cThis sword already has Flash!");
        return;
    }

    let bookSlot = -1;
    for (let i = 0; i < inventory.size; i++) {
        const item = inventory.getItem(i);
        if (
            item &&
            item.typeId === "minecraft:enchanted_book" &&
            item.nameTag === "§dFlash"
        ) {
            bookSlot = i;
            break;
        }
    }

    if (bookSlot === -1) {
        player.sendMessage("§cYou need a Flash book!");
        return;
    }

    weapon.setDynamicProperty("porter:flash", true);
    weapon.setLore([...weapon.getLore(), "§dFlash"]);
    equipment.setEquipment(EquipmentSlot.Mainhand, weapon);

    const book = inventory.getItem(bookSlot);
    if (book.amount > 1) {
        book.amount -= 1;
        inventory.setItem(bookSlot, book);
    } else {
        inventory.setItem(bookSlot, undefined);
    }

    player.sendMessage("§d⚡ Flash successfully applied!");
}

world.afterEvents.playerInteractWithBlock.subscribe((event) => {
    if (event.block.typeId !== "porter:deadly_anvil") return;

    openDeadlyAnvil(event.player).catch((error) => {
        console.warn("Flash Anvil error: " + error);
        event.player.sendMessage("§cThe Flash Anvil had a problem opening. Check the server log.");
    });
});

console.warn("FLASH ANVIL BLOCK LOADED!");
