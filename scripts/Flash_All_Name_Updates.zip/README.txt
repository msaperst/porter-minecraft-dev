FLASH ANVIL - PORTER EDITION

This is a separate Bedrock add-on pair. It does not replace your existing Flash Enchantment pack.

FILES
- Deadly_Anvil_BP: the placeable custom block and its interaction script
- Deadly_Anvil_RP: the purple FLASH model and texture

INSTALL ON A BEDROCK DEDICATED SERVER
1. Copy Deadly_Anvil_BP into the server's behavior_packs folder.
2. Copy Deadly_Anvil_RP into the server's resource_packs folder.
3. Enable BOTH new packs for the world, and keep your existing Flash Enchantment behavior pack enabled.
4. Restart/reload the world.
5. In chat, run: /give @s porter:deadly_anvil
6. Place the block and interact with it. It opens the Flash anvil menu.

The Flash Anvil behavior pack depends on the existing Flash Enchantment pack UUID a6b28c91-4f73-4c2d-9e15-7b83a1d64021 and uses the same item dynamic-property key porter:flash. Keep the Flash Enchantment pack enabled so swords enchanted at the Flash Anvil block trigger lightning.

The pack uses stable manifest dependencies @minecraft/server 2.10.0 and @minecraft/server-ui 2.3.0, intended for a Bedrock runtime that supports those versions. The minimum engine is set to 1.26.0.

If you manually edit world pack lists, these IDs are:
Behavior pack UUID: de1d1a7e-73b2-43a4-9e61-cd9fc14f9f8b version 1.0.0
Resource pack UUID: 5a8d10a3-1c55-4d5a-a8e0-c3f7b61e2921 version 1.0.0

NOTES
- The model is a stylized blocky anvil with purple FLASH on both long faces.
- The menu opens on interaction with the custom block.
- This add-on is separate from the old vanilla-anvil interaction listener. Remove/disable that old listener if you no longer want ordinary anvils to open the menu.


FLASH BOOK NAME UPDATE
Copy Flash_Enchantment_Update/scripts/flash_book.js into your existing Flash Enchantment behavior pack at scripts/flash_book.js, replacing the old file. This gives the enchanted book the exact name "Flash". The Flash Anvil menu searches for that exact name.
